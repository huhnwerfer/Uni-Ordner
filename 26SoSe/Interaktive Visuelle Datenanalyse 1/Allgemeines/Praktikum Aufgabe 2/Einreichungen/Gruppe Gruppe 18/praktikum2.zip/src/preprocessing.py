import pandas as pd

def clean(inputName, outputName):
    data = pd.read_csv(inputName, dtype=str)

    intColumns = ["Magnesium", "Prolinwert"] # these can be left as they are
    for index, row in data.iterrows():
        for column in row.keys():
            value = row[column]
            while value[0] == "0" and value[:2] != "0." and len(value) > 1:
                value = value[1:]
            if column not in intColumns:
                if value[-1] == ".":
                    value = value[:-1]
                if "." not in value:
                    value += ".0"
            data.loc[index, column] = value

    outlierIndexes = []
    for index, row in data.iterrows():
        if float(row["Farbwert"]) > 10:
            outlierIndexes.append(index) # this seems very risky. but i just want to remove the one entry with 900 where all others have like up to 1.5
    
    data.drop(outlierIndexes, inplace = True)
    data.drop_duplicates(inplace=True) # in this case none should exist anyway
    data.to_csv(outputName, index=False)

def scaleAllColumns(data):
    for column in data:
        data[column] = data[column] / data[column].max() # there is no negative data to consider