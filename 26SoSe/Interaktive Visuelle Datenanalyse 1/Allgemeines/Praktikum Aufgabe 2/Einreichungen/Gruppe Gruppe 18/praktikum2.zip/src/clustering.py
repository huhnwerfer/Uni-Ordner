import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import davies_bouldin_score, silhouette_score

def getClusterings(data):
    clusterings = {}

    for numClusters in [2, 3, 4, 5]:
        kMeans = KMeans(
            n_clusters = numClusters
        )
        pCA = PCA(
            n_components = 2
        )

        clusterLabels = kMeans.fit_predict(data)
        transformedData = pCA.fit_transform(data)

        finalData = pd.DataFrame(
            np.hstack((transformedData, clusterLabels.reshape(len(clusterLabels), 1))), # merges the arrays into columns with x, y, and cluster id
            columns = ["Transformed x", "Transformed y", "Cluster ID"]
        ).reset_index() # adds "index" as a column

        finalData["Cluster ID"] = finalData["Cluster ID"].astype(int).astype(str) # necessary so that plotly does not interpret cluster IDs as continuous, but also not as 1.0 and 0.0 (with the stuff after the comma)

        clusteringData = {
            "finalData": finalData,
            "clusterLabels": clusterLabels,
            "pCA": pCA,
            "silhouetteScore": silhouette_score(data, clusterLabels),
            "daviesBouldin": davies_bouldin_score(data, clusterLabels)
        }

        clusterings[numClusters] = clusteringData
    
    return clusterings