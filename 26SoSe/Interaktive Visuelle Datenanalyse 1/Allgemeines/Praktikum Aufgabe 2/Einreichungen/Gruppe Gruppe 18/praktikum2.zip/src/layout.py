from dash import dcc, html

def getLayout(features):
    pageLayout = html.Div([
        html.H1("Linear regression (equal weights for each sample)"),
        html.H2("Select axes"),
        html.Div(
            children = [
                html.Div(
                    children = [
                        dcc.Dropdown(
                            features,
                            "Alkohol",
                            placeholder = "x",
                            id = "linear-regression-x"
                        )
                    ],
                    style = {"width" : "40vw"}
                ),
                html.Div(
                    children = [
                        dcc.Dropdown(
                            features,
                            "Apfelsaeure",
                            placeholder = "y",
                            id = "linear-regression-y"
                        )
                    ],
                    style = {"width" : "40vw"}
                )
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
                "gap" : "10px"
            }
        ),
        dcc.Graph(
            id = "linear-regression-visualization",
            style = {"width" : "70vw", "height": "70vh"}
        ),
        html.Div(
            children = [
                html.Div(
                    children = [
                        html.H4("Linear approximation:"),
                        html.H4("", id = "regression-formula")
                    ],
                    style = {"width" : "50vw"}
                ),
                html.Div(
                    children = [
                        html.H4("", id = "regression-mean-error"),
                        html.H4("", id = "regression-mean-squared-error"),
                        html.H4("", id = "regression-max-error")
                    ],
                    style = {"width" : "50vw"}
                )
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
                "gap" : "10px"
            }
        ),
        html.H1("Clustering"),
        dcc.Input(
            id = "num-clusters",
            type = "number",
            min = 2,
            max = 5,
            value = 2,
        ),
        html.Div(
            children = [
                html.Div(
                    children = [
                        html.H4("Scatterplot"),
                        dcc.Graph(
                            id = "cluster-scatter"
                        ),
                        html.H4("", "silhouette-coefficient"),
                        html.H4("", "davies-bouldin")
                    ],
                    style = {"width" : "40vw"}
                ),
                html.Div(
                    children = [
                        html.Div(
                            children=[
                                html.H4("Scree plot"),
                                dcc.Graph(id = "cluster-scree"),
                                html.H4("Silhouette"),
                                dcc.Graph(id = "cluster-silhouette"),
                            ],
                            style={"width": "40vw"}
                        ),
                    ],
                    style = {"width" : "40vw"}
                )
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
                "gap" : "10px"
            }
        )
    ])

    return pageLayout