setup wie davor

```
python3.12 -m venv .venv
source .venv/bin/activate
python3.12 -m pip install -r requirements.txt
python3.12 -B main.py
```


bereinigungsschritte:
- manchmal bei kommazahlen am ende noch ein punkt: also z.b. "13.02." statt "13.02". Deshalb alle ".," durch "," ersetzen.
- magnesium und prolinwert sind ganzzahlig; in allen anderen spalten steht z.b. "3" statt "3.0" (hab also immer .0 hinten rangemacht wenn sie noch nicht in float-notation waren)
- führende nulen bei zahlenwerten wie 01.04 entfernen

gefundenee outlier:
- farbwert 906

bemerkung: euklidische distanz einfach so zu nutzen ist doof. prolinwert dominiert einfach. idee: alle spalten normalisieren?

zum ausführen `python3.14 -B tobimain.py`