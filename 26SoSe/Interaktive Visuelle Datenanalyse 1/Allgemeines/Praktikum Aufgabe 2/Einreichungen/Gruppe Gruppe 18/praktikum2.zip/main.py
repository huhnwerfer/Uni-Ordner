from src import clustering, layout, preprocessing

from dash import Dash, dcc, html
from dash import Input, Output
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from sklearn.metrics import davies_bouldin_score, silhouette_samples, silhouette_score
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

def getErrors(w, b, xData, yData):
    errors = []
    for i in range(xData.size):
        errors.append(abs(yData.loc[i] - (w * xData.loc[i] + b)))

    return errors

if __name__ == "__main__":
    print("cleaning data...")
    preprocessing.clean("data/wein.csv", "data/wein-cleaned.csv")
    data = pd.read_csv("data/wein-cleaned.csv")
    print("normalizing data...")
    preprocessing.scaleAllColumns(data)
    features = data.columns

    print("pre-building clusters...")
    clusterings = clustering.getClusterings(data)

    print("building app...")

    app = Dash()
    app.layout = layout.getLayout(features)

    @app.callback(
        Output("linear-regression-visualization", "figure"),
        Output("regression-formula", "children"),
        Output("regression-mean-error", "children"),
        Output("regression-mean-squared-error", "children"),
        Output("regression-max-error", "children"),
        Input("linear-regression-x", "value"),
        Input("linear-regression-y", "value")
    )
    def updateLinearRegression(xColumn, yColumn):
        linearRegressionFigure = px.scatter(data, x = xColumn, y = yColumn, title = "Major regressive disorder :(")

        regressor = LinearRegression()
        regressor.fit(pd.DataFrame(data[xColumn]), pd.DataFrame(data[yColumn]))

        # visualize the regression with a line between (x1, y1) and (x2, y2)
        x1 = min(data[xColumn])
        x2 = max(data[xColumn])
        y1 = regressor.coef_[0][0] * x1 + regressor.intercept_[0]
        y2 = regressor.coef_[0][0] * x2 + regressor.intercept_[0]

        linearRegressionFigure.add_trace(go.Scatter(x = [x1, x2], y = [y1, y2], mode = "lines", name = "linear approximation"))

        formulaString = "y = " + str(regressor.coef_[0][0]) + "x + " + str(regressor.intercept_[0])

        errors = getErrors(regressor.coef_[0][0], regressor.intercept_[0], data[xColumn], data[yColumn])
        meanErrorString = "Mean error: " + str(sum(errors) / len(errors))
        meanSquaredErrorString = "Mean squared error: " + str(sum([error * error for error in errors]) / len(errors))
        maxErrorString = "Max error: " + str(max(errors))
        
        return linearRegressionFigure, formulaString, meanErrorString, meanSquaredErrorString, maxErrorString
    
    @app.callback(
        Output("cluster-scatter", "figure"),
        Output("cluster-scree", "figure"),
        Output("cluster-silhouette", "figure"),
        Output("silhouette-coefficient", "children"),
        Output("davies-bouldin", "children"),
        Input("num-clusters", "value")
    )
    def updateClusters(numClusters):
        print("whats up")

        clustering = clusterings[numClusters]

        clusterScatter = px.scatter(
            clustering["finalData"],
            x = "Transformed x",
            y = "Transformed y",
            color = "Cluster ID",
            hover_data = ["index"]
        )

        variances = clustering["pCA"].explained_variance_ratio_
        screeData = pd.DataFrame({
            "Component": [str(i) for i in range(len(variances))],
            "Relative Variance": variances
        })

        clusterScree = px.bar(
            screeData,
            x = "Component",
            y = "Relative Variance"
        )

        silhouetteValues = silhouette_samples(data, clustering["clusterLabels"])
        silhouetteData = pd.DataFrame({
            "cluster label" : clustering["clusterLabels"],
            "silhouette value" : silhouetteValues
        })

        silhouetteData = silhouetteData.sort_values("silhouette value").reset_index()

        clusterSilhouette = px.bar(
            silhouetteData,
            x = silhouetteData.index,
            y = "silhouette value",
            color = "cluster label"
        )



        return clusterScatter, clusterScree, clusterSilhouette, \
                "Silhouette Score: " + str(clustering["silhouetteScore"]), \
                "Davies Bouldin: " + str(clustering["daviesBouldin"])

    app.run(debug = False)