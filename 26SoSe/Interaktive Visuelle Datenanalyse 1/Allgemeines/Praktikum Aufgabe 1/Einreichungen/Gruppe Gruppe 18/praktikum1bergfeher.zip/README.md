# Einrichtung
Platzieren Sie die originale .csv-Datei im lokalen Pfad `data/raw.csv`. Führen Sie dann die folgenden Befehle aus (ersetzen Sie ggf. `python3.12` mit ihrer eigenen Python-Installation):
```
python3.12 -m venv .venv
source .venv/bin/activate
python3.12 -m pip install -r requirements.txt
python3.12 main.py
```
Die Applikation können Sie dann im Browser unter dem Link in der Ausgabe sehen. Beachten Sie dabei, dass Sie aufgrund der Größe der Daten abhängig von ihrem Gerät ggf. ein paar Sekunden warten müssen.

# Aufgaben
## 1. Datenbereinigung
Wir entnehmen aus den Spaltennamen, dass es sich bei den Dateneinträgen um Fußballspieler handelt. Da die Links im Datensatz zur Seite "SoFIFA" führen, ist davon auszugehen, dass es sich um Spielerdaten aus der Videospielreihe FIFA/EA Sports FC handelt.

Auch wenn uns Fachwissen in diesem Gebiet fehlt und wir die inhaltliche Qualität des Datensatzes deshalb schwer bewerten können, konnten wir einige grobe Unreinheiten erkennen. Wir wurden auf die folgenden Fehler aufmerksam:
- Es werden in der csv-Datei für String-Werte `'` statt `"` genutzt. Dies folgt nicht dem csv-Standard. Auf diese Weise werden Werte wie `'CM,CDM'` als 2 verschiedene Einträge behandelt.
  - Wir beheben den Fehler, in dem wir alle `'` durch `"` ersetzt haben. Da davor kein einzelnes `"`-Zeichen in der csv-Datei war und danach alle Spaltenzahlen passen, können wir davon ausgehen, dass hierdurch keine Information verloren wurde.
- In der Spalte "Value(in Euro)" befinden sich Werte, die die sonstige Notation brechen: "26.500.000" in Zeile 74, "16,000,000" (in Anführungszeichen) in Zeile 441, "1100000,00 €" in Zeile 12922, "925000 $" in Zeile 13119.
  - Wir löschen Teilstrings `,00 €` und und entfernen weiterhin alle Punkt- und Kommazeichen aus dem Feld "Value(in Euro)". Einträge mit dem zeichen `$` werden entfernt, da wir nicht wissen, ob eine Umrechnung erfolgen muss und damit auch nicht den echten Wert kennen.
- Weiterhin befinden sich (unserer Einschätzung nach) unmögliche Werte in der Spalte "Value(in Euro)": der Spieler Zlatan Ibrahimović hat den Eintrag -1.
  - Um solche illegalen Zahlwerte zu vermeiden, entfernen wir alle Datenpunkte, die in den von uns als numerisch bestimmten Spalten Zeichen außer den Ziffern 0 bis 9 enthalten.
  - Weiterhin haben wir eine kurze Funktion geschrieben, die für Feldern mit Links prüft, ob diese String-Werte mit "https://" beginnen. Wir dachten ursprünglich, es gäbe einen Wert, der diese Regel bricht. Auch wenn es diesen scheinbar nicht gibt, haben wir die Funktion trotzdem als Teil des Programms gelassen.
- Der Datensatz enthält Duplikate.
  - Wir nutzen die eingebaute Pandas-funktion `drop_duplicates`, um Duplikate anhand des vollen Namens, des Alias und der Nationalität zu erkennen und zu löschen.
- Manchmal existieren Werte nicht. Das spiegelt sich durch 2 aufeinanderfolgende Kommas in der csv-Datei dar.
  - Wir löschen alle Datenpunkte, die fehlende Datensätze haben (es sind in diesem Fall bloß 6), um einen überall aussagekräftigen Datensatz zu gewährleisten.

Der Einfachheit halber lesen wir die Daten beim bereinigen zweimal ein: einmal als gewöhnlichen String (um beispielsweise `'` mit `"` zu ersetzen), und dann mithilfe von Pandas als csv-Datei, um fokussiertere Schritte vorzunehmen.

## 5. Analyse und Interpretation

Wir haben keine inhaltliche Erfahrung mit dem Thema des Datensatzes und haben daher vielleicht einiges übersehen. Trotzdem können wir bestätigen, dass es sich bei den Daten nicht in erster Linie um realitätsgetreue Sportstatistiken handelt, sondern um handelbare Gegenstände in einem Videospiel. Neben den Links zur Seite SoFIFA erkennen wir das unter anderem daran, dass in der Realität geheime Werte wie das Gehalt und der Value der Spieler konsistent bekannt und fest angegeben sind. Das gleiche gilt für die Kategorien der Stats, die glockenförmig mit wenigen Ausreißern nach oben angeordnet sind, was typisch für handelbare Spielgegenstände dieser Art ist.

Wir können biologische Merkmale erkennen, die wir im kompetitiven Leistungssport dieser Kategorie erwarten würden: alle Spieler wirken männlich, der größte Teil von ihnen ist überdurchschnittlich groß und befindet sich in der Altersspanne von 20 bis 40 Jahren. Das durchschnittliche Gehalt ist für besonders junge und alte Menschen eher klein, und erreicht die größten Höhen um das Alter 30. Hierbei ist anzumerken, dass die meisten Gehälter vergleichsweise klein (im bereichn von ein paar Zehntausend) sind im Vergleich zu wenigen Ausreißern, die hunderttausende Euro verdienen.

Weitere Beobachtungen, die wir in keine Konsequenz einordnen können, sind:
- Die Mehrheit spielt mit dem rechten Fuß lieber.
- Es gibt mehr offensive als defensive Tendenzen.
- Nur ein kleiner Teil der Spieler ist auf Loan.
- CF ist die unbeliebteste Spielposition.
- Die meisten Spieler, die in Nationalmannschaften eingetragen sind, sind Auswechselspieler.
- Wirtschaftlich entwickelte Länder haben die größte Präsenz.
- Für China und Nordirland ist keine Flagge eingetragen.
