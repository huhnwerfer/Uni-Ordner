import os, sys
import dash_ag_grid as dag
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, html, dcc, Input, Output

# get count of positions played (how often someone plays each singular positions) 
def getPositionsPlayedCount(data, positions):
    positionsPlayedCount = pd.Series({position : 0 for position in positions})

    for index, row in data.iterrows():
        positionsPlayed = row["Positions Played"].split(",")
        for position in positionsPlayed:
            positionsPlayedCount[position] += 1
    positionsPlayedCount.sort_values(inplace = True, ascending = False)

    return positionsPlayedCount

# verify that stuff is int that should be int
def verifyTypeRanges(row):
    # these types need to consist of only digits
    onlyNumericalValues = ["Overall", "Potential", "Value(in Euro)", "Age", "Height(in cm)", "Weight(in kg)", "TotalStats", "BaseStats", "Wage(in Euro)", "Release Clause", "Joined On", "Weak Foot Rating", "Skill Moves", "International Reputation", "Pace Total", "Shooting Total", "Passing Total", "Dribbling Total", "Defending Total","Physicality Total", "Crossing", "Finishing", "Heading Accuracy", "Short Passing", "Volleys", "Dribbling","Curve", "Freekick Accuracy", "LongPassing", "BallControl", "Acceleration", "Sprint Speed", "Agility", "Reactions", "Balance", "Shot Power", "Jumping", "Stamina", "Strength", "Long Shots", "Aggression", "Interceptions", "Positioning", "Vision", "Penalties", "Composure", "Marking", "Standing Tackle", "Sliding Tackle", "Goalkeeper Diving", "Goalkeeper Handling", " GoalkeeperKicking", "Goalkeeper Positioning", "Goalkeeper Reflexes", "ST Rating", "LW Rating", "LF Rating", "CF Rating", "RF Rating", "RW Rating", "CAM Rating", "LM Rating", "CM Rating", "RM Rating", "LWB Rating", "CDM Rating", "RWB Rating", "LB Rating", "CB Rating", "RB Rating", "GK Rating"]
    # these types need to begin with https://
    httpsValues = ["Image Link", "National Team Image Link"]

    for onlyNumericalValue in onlyNumericalValues:
        if type(row[onlyNumericalValue]) in [int, float]:
            continue
        else:
            if not row[onlyNumericalValue].strip().isdigit():# or row[onlyNumericalValue] == "":
                return False
    
    for httpsValue in httpsValues:
        if row[httpsValue][:8] != "https://" and row [httpsValue][:8] != "-":
            input(row["Full Name"], httpsValue)
            return False
    
    return True

def cleanseData():
    with open("data/raw.csv", "r") as rawData:
        print("opening raw data file...")
        dataString = rawData.read()
    
    print("replacing ' characters with \" characters...")
    dataString = dataString.replace("'", "\"")

    print("cleaning money values containing \",00 €\"...")
    dataString = dataString.replace(",00 €", "")

    with open("data/cleaned.csv", "w") as cleanedFile:
        print("writing preliminary cleaned data...")
        cleanedFile.write(dataString)

    print("reading data as .csv...")
    data = pd.read_csv("data/cleaned.csv", dtype = {"Value(in Euro)" : str})

    print("reading and further cleaning all rows and checking for compliance...")
    indexesToRemove = []

    # transform rows
    for index, row in data.iterrows():
        # erase all full stop marks and commas
        if "." in row["Value(in Euro)"]:
            data.at[index, "Value(in Euro)"] = row["Value(in Euro)"].replace(".", "")
        if "$" in row["Value(in Euro)"]:
            indexesToRemove.append(index)
        if "," in row["Value(in Euro)"]:
            data.at[index, "Value(in Euro)"] = row["Value(in Euro)"].replace(",", "")
        
        # order fields with multi-values alphabetically (otherwise, there exist duplicates, like "CF,ST" and "ST,CF" in "Positions Played")
        data.at[index, "Positions Played"] = ",".join(sorted(row["Positions Played"].split(",")))
        data.at[index, "Best Position"] = ",".join(sorted(row["Best Position"].split(",")))

    # filter rows after transformation
    for index, row in data.iterrows():
        if row.isna().values.any() or not verifyTypeRanges(row) or int(row["Value(in Euro)"]) <= 0:
            indexesToRemove.append(index)

    print("removing all rows that break compliance...")
    data.drop(index = indexesToRemove, inplace = True)

    print("removing duplicates...")
    duplicates = data.drop_duplicates(subset = ["Full Name", "Nationality", "Age"])

    print("writing final cleaned data...")
    data.to_csv("data/cleaned.csv")



# true only if the file was called directly (as opposed to being imported by another file)
if __name__ == "__main__":

    if os.path.isfile("data/cleaned.csv") and "--no-reclean" in sys.argv:
        pass
    else:
        cleanseData()

    print("getting final input data...")

    data = pd.read_csv("data/cleaned.csv", dtype = {"Value(in Euro)" : int})

    # fields that fit on a scale from 0 to 100
    zeroHundredFields = ["Overall", "Potential", "Age", "Weight(in kg)", "Weak Foot Rating", "Skill Moves", "International Reputation", "Pace Total", "Shooting Total", "Passing Total", "Dribbling Total", "Defending Total","Physicality Total", "Crossing", "Finishing", "Heading Accuracy", "Short Passing", "Volleys", "Dribbling","Curve", "Freekick Accuracy", "LongPassing", "BallControl", "Acceleration", "Sprint Speed", "Agility", "Reactions", "Balance", "Shot Power", "Jumping", "Stamina", "Strength", "Long Shots", "Aggression", "Interceptions", "Positioning", "Vision", "Penalties", "Composure", "Marking", "Standing Tackle", "Sliding Tackle", "Goalkeeper Diving", "Goalkeeper Handling", " GoalkeeperKicking", "Goalkeeper Positioning", "Goalkeeper Reflexes", "ST Rating", "LW Rating", "LF Rating", "CF Rating", "RF Rating", "RW Rating", "CAM Rating", "LM Rating", "CM Rating", "RM Rating", "LWB Rating", "CDM Rating", "RWB Rating", "LB Rating", "CB Rating", "RB Rating", "GK Rating"]
    # fields that can not be compared
    personalFields = ["Full Name", "Known As", "Image Link", "Club Jersey Number", "National Team Jersey Number"]

    # gather data about the different value ranges in the dataset
    positions = [] # should look like ['CAM', 'CB', 'CDM', 'CF', 'CM', 'GK', 'LB', 'LM', 'LW', 'LWB', 'RB', 'RM', 'RW', 'RWB', 'ST']
    nationalities = []
    clubs = []
    for index, row in data.iterrows():
        for position in row["Positions Played"].split(","):
            if position not in positions:
                positions.append(position)
        if row["Nationality"] not in nationalities:
            nationalities.append(row["Nationality"])
        if row["Club Name"] not in clubs:
            clubs.append(row["Club Name"])
    positions.sort()

    print("building app...")

    highlightedDataPoints = [5, 35] # the data points in the bottom highlighted box

    app = Dash()

    # layout is declarative
    app.layout = html.Div([
        html.H1("Task 1"),
        html.Hr(),
        html.H2("General Filters applied to all figures"),
        html.Div(
            children = [
                html.Div(
                    children = [
                        html.H4("Filter by Nationality:"),
                        dcc.Dropdown(
                            nationalities,
                            nationalities,
                            multi = True,
                            placeholder = "Select Nationalities",
                            id="nationality-filter"
                        ),
                    ],
                    style = {"width" : "40vw"}
                ),
                html.Div(
                    children = [
                        html.H4("Filter by Club Name:"),
                        dcc.Dropdown(
                            clubs,
                            clubs,
                            multi = True,
                            placeholder = "Select Clubs",
                            id="club-filter"
                        ),
                    ],
                    style = {"width" : "40vw"}
                )
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
                "gap" : "10px"
            }
        ),
        html.Hr(),
        html.H2("General overview of fields and their distributions"),
        html.H3("Fields with unique distributions"),
        html.Div(
            children = [
                dcc.Graph(
                    id = "value-in-euro-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "wage-in-euro-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "release-clause-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "height-in-cm-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "total-stats-graph",
                    style = {"width" : "20vw"}
                ),
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
            }
        ),
        html.Div(
            children = [
                dcc.Graph(
                    id = "base-stats-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "on-loan-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "preferred-foot-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "attacking-work-rate-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "defensive-work-rate-graph",
                    style = {"width" : "20vw"}
                ),
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
            }
        ),
        html.H3("Fields with numerical Range within approx. 1-100"),
        dcc.Checklist(id = "zeroHundredFieldsChecklist", options = zeroHundredFields, value = ["Overall"], inline = True),
        dcc.Graph(id = "zeroHundredFieldsGraph"),
        html.H3("Fields with categoric values"),
        html.Div(
            children = [
                dcc.Graph(
                    id = "nationalities-graph",
                    style = {"width" : "20vw"}
                ),
                dcc.Graph(
                    id = "clubs-graph",
                    style = {"width" : "27vw"}
                ),
                dcc.Graph(
                    id = "positions-played-combinations-graph",
                    style = {"width" : "18vw"}
                ),
                html.Div(
                    children = [
                        dcc.Graph(
                            id = "positions-played-singular-graph",
                            style = {"width" : "17vw"}
                        ),
                        dcc.Graph(
                            id = "club-position-graph",
                            style = {"width" : "17vw"}
                        ),
                    ]
                ),
                html.Div(
                    children = [
                        dcc.Graph(
                            id = "best-position-graph",
                            style = {"width" : "18vw"}
                        ),
                        dcc.Graph(
                            id = "national-team-position-graph",
                            style = {"width" : "18vw"}
                        )
                    ],
                ),
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
            }
        ),
        html.Div(
            children = [
                
            ]
        ),
        html.H4("Personal Data and Clubs"),
        html.Div(
            children = [
                html.Div(
                    children = [
                        dag.AgGrid(
                            id = "national-team-grid",
                            dashGridOptions = {"enableCellTextSelection" : True, "ensureDomOrder" : True},
                            rowData = data[data["National Team Name"] != "-"].groupby(["National Team Name", "National Team Image Link"]).size().reset_index(name = "Count").to_dict("records"),
                            columnDefs = [
                                {"field" : "National Team Name"},
                                {"field" : "National Team Image Link"},
                                {"field" : "Count", "headerName" : "Members"},
                            ],
                            style={"height": "400px", "width": "40vw"}
                        ),
                        dag.AgGrid(
                            id = "personal-grid",
                            dashGridOptions = {"enableCellTextSelection" : True, "ensureDomOrder" : True},
                            rowData = data.filter(items = personalFields).to_dict("records"),
                            columnDefs = [{"field" : personalFields} for personalFields in personalFields],
                            style={"height": "400px", "width": "40vw"}
                        )
                    ]
                ),
                html.Div(
                    children = [
                        dcc.Graph(
                            id = "joined-on-graph",
                            style = {"width" : "40vw"}
                        ),
                        dcc.Graph(
                            id = "contract-until-graph",
                            style = {"width" : "40vw"}
                        )
                    ]
                )
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
            }
        ),
        html.Hr(),
        html.H2("Comparing multiple data points"),
        html.Div(
            children = [
                dcc.Graph(
                    id = "compare-age-wage-transparent-graph",
                    style = {"width" : "40vw"}
                ),
                dcc.Graph(
                    id = "compare-age-wage-box-graph",
                    style = {"width" : "40vw"}
                ),
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
            }
        ),
        html.Div(
            children = [
                dcc.Graph(
                    id = "compare-age-overall-transparent-graph",
                    style = {"width" : "40vw"}
                ),
                dcc.Graph(
                    id = "compare-age-overall-box-graph",
                    style = {"width" : "40vw"}
                ),
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
            }
        ),
        html.H4("Inspect via index (begins at 0, may take time to update) (empty means all)"),
        dcc.Input(
            id = "highlighted-input",
            value = "5,35"
        ),
        dag.AgGrid(
            id = "highlighted-data-points-grid",
            dashGridOptions = {"enableCellTextSelection" : True, "ensureDomOrder" : True},
            rowData = data[data.index.isin(highlightedDataPoints)].to_dict("records"),
            columnDefs = [{"field" : column} for column in data.rename(columns = {"Unnamed: 0" : "index"}).columns],
            style={"height": "400px"}
        )
    ])

    @app.callback(
        Output("zeroHundredFieldsGraph", "figure"),
        Input("nationality-filter", "value"),
        Input("club-filter", "value"),
        Input("zeroHundredFieldsChecklist", "value"),
    )
    def generateZeroHundredFieldsGraph(selectedNations, selectedClubs, selectedFields):
        filteredData = data.loc[(data["Nationality"].isin(selectedNations)) & (data["Club Name"].isin(selectedClubs))]

        figure = go.Figure()
        for field in selectedFields:
            figure.add_trace(go.Box(y = filteredData[field], name = field))
        return figure

    # this feels criminal
    @app.callback(
        Output("value-in-euro-graph", "figure"),
        Output("wage-in-euro-graph", "figure"),
        Output("release-clause-graph", "figure"),
        Output("height-in-cm-graph", "figure"),
        Output("total-stats-graph", "figure"),
        Output("base-stats-graph", "figure"),
        Output("on-loan-graph", "figure"),
        Output("preferred-foot-graph", "figure"),
        Output("attacking-work-rate-graph", "figure"),
        Output("defensive-work-rate-graph", "figure"),
        Output("nationalities-graph", "figure"),
        Output("clubs-graph", "figure"),
        Output("positions-played-combinations-graph", "figure"),
        Output("positions-played-singular-graph", "figure"),
        Output("club-position-graph", "figure"),
        Output("best-position-graph", "figure"),
        Output("national-team-position-graph", "figure"),
        Output("national-team-grid", "rowData"),
        Output("personal-grid", "rowData"),
        Output("joined-on-graph", "figure"),
        Output("contract-until-graph", "figure"),
        Output("compare-age-wage-transparent-graph", "figure"),
        Output("compare-age-wage-box-graph", "figure"),
        Output("compare-age-overall-transparent-graph", "figure"),
        Output("compare-age-overall-box-graph", "figure"),
        Output("highlighted-data-points-grid", "rowData"),
        Input("nationality-filter", "value"),
        Input("club-filter", "value"),
        Input("highlighted-input", "value")
    )
    def filterAll(selectedNations, selectedClubs, highlightedInput):
        filteredData = data.loc[(data["Nationality"].isin(selectedNations)) & (data["Club Name"].isin(selectedClubs))].rename(columns = {"Unnamed: 0" : "index"})

        try:
            highlightedDataPoints = [int(value.strip()) for value in highlightedInput.split(",")]
        except:
            highlightedDataPoints = []

        valueInEuroGraph = px.box(
            filteredData["Value(in Euro)"],
            title = "Value (in Euro) (logarithmic)",
            y = "Value(in Euro)",
            log_y = True,
        )
        wageInEuroGraph = px.box(
            filteredData["Wage(in Euro)"],
            title = "Wage (in Euro) (logarithmic)",
            y = "Wage(in Euro)",
            log_y = True,
        )
        releaseClauseGraph = px.box(
            filteredData["Release Clause"],
            title = "Release Clause (logarithmic)",
            y = "Release Clause",
            log_y = True,
        )
        heightInCmGraph = px.violin(
            filteredData["Height(in cm)"],
            title = "Height (in cm)",
            y = "Height(in cm)"
        )
        totalStatsGraph = px.violin(
            filteredData["TotalStats"],
            title = "TotalStats",
            y = "TotalStats"
        )
        baseStatsGraph = px.violin(
            filteredData["BaseStats"],
            title = "BaseStats",
            y = "BaseStats"
        )
        onLoanGraph = px.pie(
            filteredData,
            names = "On Loan",
            title = "On Loan",
        )
        preferredFootGraph = px.pie(
            filteredData,
            names = "Preferred Foot",
            title = "Preferred Foot",
        )
        attackingWorkRateGraph = px.pie(
            filteredData,
            names = "Attacking Work Rate",
            title = "Attacking Work Rate",
        )
        defensiveWorkRateGraph = px.pie(
            filteredData,
            names = "Defensive Work Rate",
            title = "Defensive Work Rate",
        )
        nationalitiesGraph = px.bar(
            filteredData["Nationality"].value_counts().reset_index(),
            x = "count",
            y = "Nationality",
            orientation = "h",
            height = 1000,
            title = "Nationalities (Zoomable) (logarithmic)",
            log_x = True
        )
        clubsGraph = px.bar(
            filteredData["Club Name"].value_counts().reset_index(),
            x = "count",
            y = "Club Name",
            orientation = "h",
            height = 1000,
            title = "Clubs (Zoomable)"
        )
        positionsPlayedCombinationsGraph = px.bar(
            filteredData["Positions Played"].value_counts().reset_index(),
            x = "count",
            y = "Positions Played",
            orientation = "h",
            log_x = True,
            height = 1000,
            title = "Positions Played (Combinations) (logarithmic)"
        )
        positionsPlayedCount = getPositionsPlayedCount(filteredData, positions)
        positionsplayedSingularGraph = px.bar(
            pd.DataFrame({"Position Played" : positionsPlayedCount.index, "count" : positionsPlayedCount.values}),
            x = "count",
            y = "Position Played",
            orientation = "h",
            log_x = True,
            height = 500,
            title = "Positions Played (Singular)"
        )
        clubPositionGraph = px.bar(
            filteredData["Club Position"].value_counts().reset_index(),
            x = "count",
            y = "Club Position",
            orientation = "h",
            log_x = True,
            height = 500,
            title = "Club Position (logarithmic)"
        )
        bestPositionGraph = px.bar(
            filteredData["Best Position"].value_counts().reset_index(),
            x = "count",
            y = "Best Position",
            orientation = "h",
            log_x = True,
            height = 500,
            title = "Best Positions"
        )
        nationalTeamPositionGraph = px.bar(
            filteredData[data["National Team Position"] != "-"]["National Team Position"].value_counts().reset_index(),
            x = "count",
            y = "National Team Position",
            orientation = "h",
            height = 500,
            title = "National Team Position"
        )
        nationalTeamGridData = filteredData[filteredData["National Team Name"] != "-"].groupby(["National Team Name", "National Team Image Link"]).size().reset_index(name = "Count").to_dict("records")
        personalGridData = filteredData.filter(items = personalFields).to_dict("records")
        joinedOnGraph = px.histogram(
            filteredData["Joined On"],
            range_x = [2000, 2026],
            height = 400,
            log_y = True,
            title = "Joined on (logarithmic)"
        )
        contractUntilGraph = px.histogram(
            filteredData["Contract Until"],
            range_x = [2020, 2040],
            height = 400,
            log_y = True,
            title = "Contract Until (logarithmic)"
        )
        compareAgeWageTransparentGraph = px.scatter(
            filteredData,
            x = "Age",
            y = "Wage(in Euro)",
            opacity = 0.2,
            title = "Age compared to Wage in Euro (transparent scatter)"
        )
        compareAgeWageBoxGraph = px.box(
            filteredData,
            x = "Age",
            y = "Wage(in Euro)",
            title = "Age compared to Wage in Euro (box plot) (logarithmic)"
        )
        compareAgeOverallTransparentGraph = px.scatter(
            filteredData,
            x = "Age",
            y = "Overall",
            opacity = 0.2,
            title = "Age compared to Overall (transparent scatter)"
        )
        compareAgeOverallBoxGraph = px.box(
            filteredData,
            x = "Age",
            y = "Overall",
            title = "Age compared to Overall (box plot)"
        )

        filteredData = filteredData.reset_index()
        if highlightedDataPoints == []:
            highlightedDataPointsData = filteredData.to_dict("records")
        else:
            highlightedDataPointsData = filteredData[filteredData["index"].isin(highlightedDataPoints)].to_dict("records")

        return valueInEuroGraph, wageInEuroGraph, releaseClauseGraph, heightInCmGraph, totalStatsGraph, baseStatsGraph, onLoanGraph, preferredFootGraph, \
                attackingWorkRateGraph, defensiveWorkRateGraph, nationalitiesGraph, clubsGraph, positionsPlayedCombinationsGraph, positionsplayedSingularGraph, \
                clubPositionGraph, bestPositionGraph, nationalTeamPositionGraph, nationalTeamGridData, personalGridData, joinedOnGraph, contractUntilGraph, \
                compareAgeWageTransparentGraph, compareAgeWageBoxGraph, compareAgeOverallTransparentGraph, compareAgeOverallBoxGraph, highlightedDataPointsData

    app.run(debug = False) # stuff might be printed multiple times if debug mode is on

