from src import cleaning, layout

import pydot

import pandas as pd
import plotly.express as px

from dash import Dash, Input, Output
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import cross_validate
from sklearn.tree import DecisionTreeClassifier, export_graphviz
from sklearn.utils import resample

if __name__ == "__main__":
    print("cleaning data...")
    cleaning.clean("data/raw.csv")

    rawData = pd.read_csv("data/raw.csv")
    Data = pd.read_csv("data/forced-age.csv")

    print("building app...")
    app = Dash()
    app.layout = layout.getLayout(rawData)

    @app.callback(
        Output("logistic-regression-with-age-cross-val", "rowData"),
        Output("logistic-regression-with-age-cross-val-averages", "rowData"),
        Output("logistic-regression-with-age-bootstraping-values", "rowData"),
        Output("logistic-regression-with-age-confusion-matrix", "figure"),
        Output("tree-with-age-cross-val", "rowData"),
        Output("tree-with-age-cross-val-averages", "rowData"),
        Output("tree-with-age-bootstraping-values", "rowData"),
        Output("tree-with-age-confusion-matrix", "figure"),
        Output("k-means-clusters", "rowData"),
        Output("tree-image", "src"),
        Input("button", "n_clicks")
    )
    def classification(clicks):
        # logistic regression. i'll interpret "Survived" as target column. ig forcing age here makes sense since ig it would have a considerable impact
        classificationDataX = Data.drop(columns = ["PassengerId", "Survived", "Name", "Ticket", "Cabin"])
        classificationDataX["Sex"] = classificationDataX["Sex"].apply(lambda x : 0 if x == "female" else 1 if x == "male" else 0.5) # müssen in zahlwert umgewandelt werden
        classificationDataX["Embarked"] = classificationDataX["Embarked"].apply(lambda x : -1 if x == "S" else 0 if x == "C" else 1) # enkodieren wir so vlt. andere richtungen? positive vielfache vermeiden? boarding order war 
        classificationDataY = Data["Survived"]

        bootstrappingTrainingIndices = resample(range(0, len(Data)))
        bootstrappingTestingIndices = [i for i in range(0, len(Data)) if i not in bootstrappingTrainingIndices]

        bootstrappingTrainingDataX = classificationDataX.iloc[bootstrappingTrainingIndices]
        bootstrappingTrainingDataY = classificationDataY.iloc[bootstrappingTrainingIndices]
        bootStrappingTestDataX = classificationDataX.iloc[bootstrappingTestingIndices]
        bootStrappingTestDataY = classificationDataY.iloc[bootstrappingTestingIndices]

        logisticRegressor = LogisticRegression(max_iter = 2000) # set the iterations from 100 to 1000 to guarantee convergence (with 1000, not all runs hat time to converge)

        crossValidationLogisticRegressorResultsDataFrame = pd.DataFrame(cross_validate(logisticRegressor, classificationDataX, classificationDataY, cv = 10, scoring = ["accuracy", "precision", "recall", "f1"])) \
            .rename(mapper = {"test_accuracy" : "Accuracy", "test_precision" : "Precision", "test_recall" : "Recall", "test_f1" : "F1"}, axis = "columns")
        
        crossValidationLogisticRegressorResultsAverages = [{
            "Accuracy" : crossValidationLogisticRegressorResultsDataFrame["Accuracy"].mean(),
            "Precision" : crossValidationLogisticRegressorResultsDataFrame["Precision"].mean(),
            "Recall" : crossValidationLogisticRegressorResultsDataFrame["Recall"].mean(),
            "F1" : crossValidationLogisticRegressorResultsDataFrame["F1"].mean(),
        }]

        crossValidationLogisticRegressorResults = crossValidationLogisticRegressorResultsDataFrame.to_dict("records")

        bootStrappingLogisticRegressorTestPredictions = logisticRegressor.fit(bootstrappingTrainingDataX, bootstrappingTrainingDataY) \
            .predict(bootStrappingTestDataX)
        
        bootStrappingLogisticRegressorResults = [{
            "Accuracy" : accuracy_score(bootStrappingTestDataY, bootStrappingLogisticRegressorTestPredictions),
            "Precision" : precision_score(bootStrappingTestDataY, bootStrappingLogisticRegressorTestPredictions),
            "Recall" : recall_score(bootStrappingTestDataY, bootStrappingLogisticRegressorTestPredictions),
            "F1" : f1_score(bootStrappingTestDataY, bootStrappingLogisticRegressorTestPredictions)
        }]

        logisticRegressorBootStrappingConfusionMatrix = px.imshow(
            confusion_matrix(bootStrappingTestDataY, bootStrappingLogisticRegressorTestPredictions),
            color_continuous_scale = ["White", "Teal"],
            labels = {"x" : "Predicted Value", "y" : "True Value"}
        )

        treeClassifier = DecisionTreeClassifier(max_depth = 4)
        
        crossValidationTreeClassifierResultsDataFrame = pd.DataFrame(cross_validate(treeClassifier, classificationDataX, classificationDataY, cv = 10, scoring = ["accuracy", "precision", "recall", "f1"])) \
            .rename(mapper = {"test_accuracy" : "Accuracy", "test_precision" : "Precision", "test_recall" : "Recall", "test_f1" : "F1"}, axis = "columns")

        crossValidationTreeClassifierResultsAverages = [{
            "Accuracy" : crossValidationTreeClassifierResultsDataFrame["Accuracy"].mean(),
            "Precision" : crossValidationTreeClassifierResultsDataFrame["Precision"].mean(),
            "Recall" : crossValidationTreeClassifierResultsDataFrame["Recall"].mean(),
            "F1" : crossValidationTreeClassifierResultsDataFrame["F1"].mean(),
        }]

        crossValidationTreeClassifierResults = crossValidationTreeClassifierResultsDataFrame.to_dict("records")

        bootStrappingTreeClassifierTestPredictions = treeClassifier.fit(bootstrappingTrainingDataX, bootstrappingTrainingDataY) \
            .predict(bootStrappingTestDataX)
        
        bootStrappingTreeClassifierResults = [{
            "Accuracy" : accuracy_score(bootStrappingTestDataY, bootStrappingTreeClassifierTestPredictions),
            "Precision" : precision_score(bootStrappingTestDataY, bootStrappingTreeClassifierTestPredictions),
            "Recall" : recall_score(bootStrappingTestDataY, bootStrappingTreeClassifierTestPredictions),
            "F1" : f1_score(bootStrappingTestDataY, bootStrappingTreeClassifierTestPredictions)
        }]

        decisionTreeBootStrappingConfusionMatrix = px.imshow(
            confusion_matrix(bootStrappingTestDataY, bootStrappingTreeClassifierTestPredictions),
            color_continuous_scale = ["White", "Teal"],
            labels = {"x" : "Predicted Value", "y" : "True Value"}
        )

        clusteringResults = []
        kMeansData = pd.concat([classificationDataX, classificationDataY], axis = 1)
        kMeansDataPredictions = KMeans(n_clusters = 3).fit_predict(kMeansData)
        for clusterIndex in [0, 1, 2]:
            clusterSize = 0
            clusterSurvived = 0
            clusterDeceased = 0
            for index in range(len(kMeansData)):
                if kMeansDataPredictions[index] == clusterIndex:
                    clusterSize += 1
                    if kMeansData.loc[index]["Survived"] == 1:
                        clusterSurvived += 1
                    else:
                        clusterDeceased += 1
            clusteringResults.append({
                "Cluster Index" : clusterIndex,
                "Size" : clusterSize,
                "Survived" : clusterSurvived,
                "Deceased": clusterDeceased
            })

        pydot.graph_from_dot_data(export_graphviz(treeClassifier, feature_names = classificationDataX.columns, filled = True))[0].write_png("assets/tree.png")
        imageSource = app.get_asset_url("tree.png")

        return crossValidationLogisticRegressorResults, crossValidationLogisticRegressorResultsAverages, bootStrappingLogisticRegressorResults, logisticRegressorBootStrappingConfusionMatrix, crossValidationTreeClassifierResults, crossValidationTreeClassifierResultsAverages, bootStrappingTreeClassifierResults, decisionTreeBootStrappingConfusionMatrix, clusteringResults, imageSource

    app.run(debug = False)