setup wie sonst


denke mal es sind mitfahrer*innen der titanic

untersuchung:
visuelles überfliegen. (nix gesehen)
anschauen der wertebereiche der spalten. (beobachtung: alter ist meistens auf int gerundet, aber manchmal auch .5 oder .67). bei SibSp wusste ich nicht, was das bedeuten soll, also hab gegoogelt und quelldatensatz gefunden: https://www.kaggle.com/datasets/yasserh/titanic-dataset. die sage-family waren anscheinend zu 7. da, trotzdem steht da, dass sie mit 8 ihrer spouses und siblings da waren. hatten sie alle mehrere spouses? das ticketbenennungssystem ist unklar. spalte "cabin" scheint neu zu sein, aber nicht sicher weil ich mich nicht bei kaggle einloggen werde.

probleme: age und cabin scheinen oft zu fehlen (vermutlich genuinely unbekannt). nur 183 der 891 sind vollständig (204 enthalten daten über kabine, 714 übers alter). beim alter könnte man vlt. argumentieren, dass man nansachen droppt, aber bei kabine würde der großteil verschwinden.

index und passengerid musste als datenspalte gelöscht werden!!