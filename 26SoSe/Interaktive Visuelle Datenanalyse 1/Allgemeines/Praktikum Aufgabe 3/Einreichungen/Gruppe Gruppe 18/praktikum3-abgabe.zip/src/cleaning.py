import pandas as pd

def clean(fileName):
    rawData = pd.read_csv(fileName)
    rawData.dropna(inplace=True,subset = {"Age"})
    rawData.to_csv("data/forced-age.csv", index = False)