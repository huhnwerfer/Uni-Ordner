import dash_ag_grid as dag

from dash import dcc, html

def getLayout(data):
    pageLayout = html.Div([
        html.H1("Requiring age to be known"),
        html.Button("Calculate", id = "button"),
        html.Div(
            children = [
                html.Div(
                    children = [
                        html.H2("Logistic Regression"),
                        html.H3("Ten folds"),
                        dag.AgGrid(
                            id = "logistic-regression-with-age-cross-val",
                            columnDefs = [
                                {"field" : "Accuracy", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Precision", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Recall", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "F1", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                            ],
                            columnSize = "sizeToFit",
                            style={"height": "500px", "width": "30vw"}
                        ),
                        html.H3("Averages of ten folds"),
                        dag.AgGrid(
                            id = "logistic-regression-with-age-cross-val-averages",
                            columnDefs = [
                                {"field" : "Accuracy", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Precision", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Recall", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "F1", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                            ],
                            columnSize = "sizeToFit",
                            style={"height": "100px", "width": "30vw"}
                        ),
                        html.H3("Bootstrapping .632"),
                        dag.AgGrid(
                            id = "logistic-regression-with-age-bootstraping-values",
                            columnDefs = [
                                {"field" : "Accuracy", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Precision", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Recall", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "F1", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                            ],
                            columnSize = "sizeToFit",
                            style={"height": "100px", "width": "30vw"}
                        ),
                        html.H3("Confusion matrix for bootstrapping .632"),
                        dcc.Graph(id = "logistic-regression-with-age-confusion-matrix")
                    ],
                    style = {"width" : "30vw"}
                ),
                html.Div(
                    children = [
                        html.H2("Decision Tree"),
                        html.H3("Ten folds"),
                        dag.AgGrid(
                            id = "tree-with-age-cross-val",
                            columnDefs = [
                                {"field" : "Accuracy", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Precision", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Recall", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "F1", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                            ],
                            columnSize = "sizeToFit",
                            style={"height": "500px", "width": "30vw"}
                        ),
                        html.H3("Averages of ten folds"),
                        dag.AgGrid(
                            id = "tree-with-age-cross-val-averages",
                            columnDefs = [
                                {"field" : "Accuracy", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Precision", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Recall", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "F1", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                            ],
                            columnSize = "sizeToFit",
                            style={"height": "100px", "width": "30vw"}
                        ),
                        html.H3("Bootstrapping .632"),
                        dag.AgGrid(
                            id = "tree-with-age-bootstraping-values",
                            columnDefs = [
                                {"field" : "Accuracy", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Precision", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Recall", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "F1", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                            ],
                            columnSize = "sizeToFit",
                            style={"height": "100px", "width": "30vw"}
                        ),
                        html.H3("Confusion matrix for bootstrapping .632"),
                        dcc.Graph(id = "tree-with-age-confusion-matrix")
                    ],
                    style = {"width" : "30vw"}
                ),
                html.Div(
                    children = [
                        html.H2("K-means"),
                        html.H3("Cluster values"),
                        dag.AgGrid(
                            id = "k-means-clusters",
                            columnDefs = [
                                {"field" : "Cluster Index", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Size", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Survived", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                                {"field" : "Deceased", 'valueFormatter': {"function":"""d3.format(",.3f")(params.value)"""}},
                            ],
                            columnSize = "sizeToFit",
                            style={"height": "400px", "width": "30vw"}
                        )
                    ]
                )
            ],
            style = {
                "display" : "flex",
                "flexDirection": "row",
                "gap" : "10px"
            }
        ),
        html.Img(id = "tree-image", style = {"width": "100%"})
    ])

    return pageLayout