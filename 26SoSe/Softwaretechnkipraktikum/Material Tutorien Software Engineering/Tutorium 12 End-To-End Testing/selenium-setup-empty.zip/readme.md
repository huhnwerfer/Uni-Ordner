# Selenium Books Scraper

## Init project

```bash
npm init -y
```

## Install Selenium drivers

```bash
npm install selenium-webdriver
```

## Start app

```bash
node scraper-main.js
```

## Needed later on for CI only

**Chrome users:**

```bash
npm install chromedriver --save-dev
```

**Firefox users:**

```bash
npm install geckodriver --save-dev
```

**Safari users:**

```bash
npm install safaridriver --save-dev
```
