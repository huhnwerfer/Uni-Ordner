//TASK: Store the prices of ALL books in the shop
//BONUS: Store the star-rating aswell
//Example: {"price": "£51.77", "rating": 3}, {"price": "£53.74", "rating": 1}, ...


