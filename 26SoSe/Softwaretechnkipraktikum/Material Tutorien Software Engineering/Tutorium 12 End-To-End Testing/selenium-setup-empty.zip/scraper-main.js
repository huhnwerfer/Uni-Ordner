const { Builder } = require("selenium-webdriver");    //Import core classes
const chrome = require("selenium-webdriver/chrome");  //Import chrome-specific configuration


//IMPORT our custom scrapers (and tests)
//const { scrapeFirstPage } = require("./scrapers/scrapeFirstPageTitles.js");
//const { scrapeFantasyCategory } = require("./scrapers/scrapeFantasyTitles.js");
//const { scrapePricesAndStars } = require("./scrapers/scrapePricesAndStars.js");
//const { testEmptyCategories } = require("./scrapers/testEmptyCategories.js");
//const { testRandomBookDescriptions } = require("./scrapers/testBookDescriptions.js")

const HEADLESS = false;

let browser; //main selenium object that represents the running browser

async function main() {
  try {

    //options object that stores browser startup flags
    let options = new chrome.Options();

    if (HEADLESS) {
      options.addArguments("--headless=new");
      
      //firefox version: 
      //options.addArguments("-headless");
    }

    //Create the browser builder and launch
    browser = await new Builder()
      .forBrowser("chrome")
      .setChromeOptions(options)
      .build();

    
    //RUN our custom scrapers
    //await scrapeFirstPage(browser);
    //await scrapeFantasyCategory(browser);
    //await scrapePricesAndStars(browser);
    //await testEmptyCategories(browser);
    //await testRandomBookDescriptions(browser,30);
    

  } catch (err) {
    console.error("Error scraping books:", err);
  } //finally { browser.quit(); } //commenting this out keeps browser open
}

main();