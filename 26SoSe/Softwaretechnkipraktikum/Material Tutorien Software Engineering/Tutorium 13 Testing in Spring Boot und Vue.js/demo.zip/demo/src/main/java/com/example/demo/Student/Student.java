package com.example.demo.Student;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Student {
    @Id
    private int matrikel;

    private String name;
    private String email;
}
