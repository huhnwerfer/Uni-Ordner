package com.example.demo.Student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
    private final StudentRepository studentRepository;

    @Autowired
    public StudentService (StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public List<Student> getAllStudents () {
        return studentRepository.findAll();
    }

    public Student addStudent (Student student) {
        return studentRepository.save(student);
    }

    public void deleteStudent (int matrikel) {
        studentRepository.deleteById(matrikel);
    }

    public Student updateStudentEmail (int matrikel, String newEmail) {
        Student student = studentRepository.findById(matrikel)
            .orElseThrow(() -> new IllegalArgumentException("Kein Studierender mit gegebener Matrikelnummer in Datenbank!"));

        student.setEmail(newEmail);

        return studentRepository.save(student);
    }
}
