package com.example.demo.unit_tests.student;

public class StudentServiceTest {

}
