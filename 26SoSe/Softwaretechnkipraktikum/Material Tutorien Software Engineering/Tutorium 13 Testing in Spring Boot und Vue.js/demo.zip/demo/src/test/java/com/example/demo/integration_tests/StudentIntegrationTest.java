package com.example.demo.integration_tests;

public class StudentIntegrationTest {
    
}
