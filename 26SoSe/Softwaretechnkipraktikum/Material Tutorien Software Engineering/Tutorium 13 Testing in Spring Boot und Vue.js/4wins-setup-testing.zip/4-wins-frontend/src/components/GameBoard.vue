<template>
    <div class="game-board">
        <div v-for="c in columns" :key="c" class = "column" @click="$emit('chip-placed', c-1)">
            <div v-for="r in rows" :key="`${r}-${c}`" class = "cell">
                <div :class="['chip', getChipColor(rows - r, c - 1)]"></div>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { computed } from 'vue';

    const props = defineProps({
        gameField: Array
    })

    defineEmits(['chip-placed']);

    const rows = computed(() => props.gameField.length);
    const columns = computed(() => props.gameField[0]?.length || 0);

    const getChipColor = (row, column) => {
        const value = props.gameField[row][column];
        if (value == 'X') return 'red';
        if (value == 'O') return 'yellow';
        return 'empty';
    }
</script>

<style scoped>
    /* Faerbung der Chips mit CSS-Styling */
    .chip.empty { background: white; }    
    .chip.yellow { background: #ffd700; }    
    .chip.red { background: #ff4444; }

    /* Kreisrunder Chip mit Durchmemsser 40px */
    .chip {
        width: 40px;
        height: 40px;
        border-radius: 50%;
    }

    /* display: flex erlaubt es, die Elemente flexibler als Array anzuordnen,
    sonst wuerden alle Elemente (Chips) untereinander in eigenen Zeilen angeordnet werden */
    .game-board {
        display: flex;
        background: #0066cc;
        padding: 8px;
        border-radius: 8px;
    } 

    
    /* Kosmetische Anpassungen fuer GameBoard.vue: */
    .chip.empty:hover {
        transform: scale(1.05);
        background: #e6e6e6;
    }

    .cell {
        width: 46px;
        height: 46px;
        background: #ffffff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 4px;
    }

</style>