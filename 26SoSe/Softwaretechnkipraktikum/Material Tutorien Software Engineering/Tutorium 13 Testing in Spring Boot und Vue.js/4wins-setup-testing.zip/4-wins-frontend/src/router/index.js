import { createRouter, createWebHistory } from 'vue-router'

//Komponenten einbinden
import startPage from '@/pages/startPage.vue'
import gamePage from '@/pages/gamePage.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    //Hier Routen zu den Komponenten einfügen
    { path: '/', component: startPage },
    { path: '/game', component: gamePage },
  ],
})

export default router
