<template>
    <div class="page">
        <h1>Connect Four Game</h1>

        <div class="form">
            <p>Width:</p>
            <input v-model.number="width" type="number" />

            <p>Height:</p>
            <input v-model.number="height" type="number" />

            <p>Player 1:</p>
            <input v-model.number="name1" type="text" />

            <p>Player 2:</p>
            <input v-model.number="name2" type="text" />

            <button @click="startGame">Start Game</button>
        </div>
    </div>
</template>

<script setup>
import { useRouter } from 'vue-router';
import { ref } from 'vue';

const router = useRouter();

const width = ref(7);
const height = ref(6);
const name1 = ref("Red");
const name2 = ref("Yellow");

function startGame() {
    if (width.value < 4 || height.value < 4) {
        alert("Width and height must be >3");
    } else if (name1.value == "" || name2.value == "") {
        alert("Player names can't be empty");
    } 
    else {
        router.push({
            path: '/game',
            query: {
                width: width.value,
                height: height.value,
                name1: name1.value,
                name2: name2.value,
            }
        })
    }    
}

</script>


<style scoped>
    /* Kosmetische Anpassungen fuer startPage.vue: */
    .page {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
    }

    .form {
        font-family: 'Trebuchet MS';
        display: flex;
        flex-direction: column;
        padding-left: 60px;
        padding-right: 60px;
        background: #98d4ff;
        border-radius: 10px;
    }

    h1 {
        font-family: 'Trebuchet MS';
    }

    p {
        font-family: 'Trebuchet MS';
        font-weight: 600;
        color: #06425a;
        font-size: 16px;
        margin-top: 10px;
        margin-bottom: 2px;
    }

    input {
        background: #fbfbff;
        padding: 4px;
        border-radius: 4px;
        outline: none;
    }

    button {
        margin: 15px;
        background: #0b6cb3;
        color: #fff;
        border: none;
        padding: 4px;
        border-radius: 4px;
        cursor: pointer;
        font-weight: 700;
    }



</style>