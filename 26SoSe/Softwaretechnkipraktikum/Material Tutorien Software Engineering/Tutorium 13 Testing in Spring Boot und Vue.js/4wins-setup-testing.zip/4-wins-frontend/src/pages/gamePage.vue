<template>
    <div class="game-page">
        <h1>Connect Four Game</h1>

        <div v-if="gameState" class="game-info">
            <h2 v-if="!gameState.gameOver">{{ gameState.currentPlayerName }}'s Turn</h2>
            <h2 v-if="gameState.gameOver">🎉Game is Over, {{ gameState.winnerName }} won🎉</h2>
        </div>

        <div v-if="fieldExists" class="game-container">
            <GameBoard
              :gameField="gameState.playingField"
              @chip-placed="placeChip"
            />  
        </div>

        <div class="game-controls">
            <button @click="initGame">Restart Game</button>
            <button @click="backToMenu">Back to Menu</button>
        </div>

    </div>    
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import GameBoard from '@/components/GameBoard.vue';

const router = useRouter();
const route = useRoute();

const API_BASE_URL = 'http://localhost:8080/api/single';

const gameState = ref(null);

const height = ref(parseInt(route.query.height));
const width = ref(parseInt(route.query.width));
const playerOneName = ref("Red");
const playerTwoName = ref("Yellow");

const fieldExists = computed(() =>  gameState.value?.playingField?.length > 0);

const initGame = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                playerOneName: playerOneName.value,
                playerTwoName: playerTwoName.value,
                height: height.value,
                width: width.value,
            })
        });

        //Game State laden
        await updateGameState();
    } catch (error) {
        console.error("Failed to init game: ", error);
    }
};

const updateGameState = async () => {
    try {
        //TODO: an api call weiter oben angleichen
        const response = await fetch (`${API_BASE_URL}/game-state`);
        gameState.value = await response.json();
        console.log("Game state: ");
        console.log(gameState.value);
        
    } catch (error) {
        console.error("Failed to update game state: ", error);
    }
}
const placeChip = async (column) => {
    if (!fieldExists.value) {
        console.error("Game field does not exist.");
        return;
    } else if (gameState.value.gameOver) {
        alert("Game is over, " + gameState.value.winnerName + " won.");
        return;
    } else {
        try {
            const response = await fetch(`${API_BASE_URL}/place`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    column 
                })
            });

            //Game State updaten
            await updateGameState();
        } catch (error) {
            console.error("Failed to place chip: ", error);
        }
    }
}

const backToMenu = () => {
    router.push('/');
}

onMounted(() => initGame());

</script>

<style scoped>
    /* Flex-Layout verhindert, dass Elemente die ganze Zeile einnehmen, und erlaubt uns
    eine flexiblere Anordnung der Elemente */
    .game-page {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    
    /* Kosmetische Anpassungen fuer gamePage.vue: */
    .game-controls button {
        background: #005ea2;
        color: white;
        font-family: 'Trebuchet MS';
        font-size: 20px;
        border: none;
        padding: 10px;
        margin: 10px;
        border-radius: 10px;
        cursor: pointer;
    }

    .game-controls button:hover {
        transform: scale(1.1);
    }

    
    h1 {
        font-family: 'Trebuchet MS';
        margin-top: 30px;
        margin-bottom: 0px;
        font-weight: 700;
        color: #023a5f;
    }

    h2 {
        font-family: 'Trebuchet MS';
        margin-top: 15px;
        margin-bottom: 10px;
    }

</style>