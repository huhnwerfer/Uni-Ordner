# Four Wins game API.

## Prerequisites

This API uses Spring, Maven, and later on Docker which need to be installed beforehand.

## How to Run

1. Create the **wrapper** by running
   ```bash
   ./mvnw wrapper:wrapper
   ```
   or
   ```bash
   mvn wrapper:wrapper
   ```
   depending on your local setup.

2. **Build** the stystem by running
   ```bash
   ./mvnw clean install
   ```
   or
   ```bash
   mvn clean install
   ```
   depending on your local setup.

3. **Start** the stystem by running
   ```bash
   ./mvnw spring-boot:run -X
   ```
   or
   ```bash
   mvn spring-boot:run -X   
   ```
   depending on your local setup. 
   The `-X` can be ommitted. It allows for a debug view, displaying more logs in case of, for example, errors.

## Troubleshooting

Sometimes, changes are not correctly loaded in the local console. In that case, a reload is required. 