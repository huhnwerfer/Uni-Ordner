package four_wins.api.model;

import java.util.ArrayList;
import java.util.List;

import four_wins.api.types.GameState;

public class FourWinsGameField {

    private char[][] playingField;
    private Player playerOne;
    private Player playerTwo;
    private GameState gameState;

    /**
     * Constructs a new Four Wins game field.
     * Initializes the playing field with the specified dimensions and sets up the
     * two players.
     * Player one is assigned the first turn.
     *
     * @param playerOne the first player (plays with 'X')
     * @param playerTwo the second player (plays with 'O')
     * @param height    the number of rows in the game field
     * @param width     the number of columns in the game field
     */
    public FourWinsGameField(Player playerOne, Player playerTwo, int height, int width) {
        initializeGameField(height, width);
        this.playerOne = playerOne;
        this.playerTwo = playerTwo;
        this.gameState = GameState.PLAYER_ONE_TURN; // Player one starts
    }

    /**
     * Resets the game field with new dimensions and players.
     * Clears the current game state and starts a new game with player one's turn.
     *
     * @param playerOne the first player
     * @param playerTwo the second player
     * @param height    the number of rows in the new game field
     * @param width     the number of columns in the new game field
     */
    public void resetGameField(Player playerOne, Player playerTwo, int height, int width) {
        initializeGameField(height, width);
        this.playerOne = playerOne;
        this.playerTwo = playerTwo;
        this.gameState = GameState.PLAYER_ONE_TURN; // Reset to player one's turn
    }

    /**
     * Gets the width (number of columns) of the game field.
     *
     * @return the number of columns in the playing field
     */
    public int getWidth() {
        return playingField[0].length;
    }

    /**
     * Gets the height (number of rows) of the game field.
     *
     * @return the number of rows in the playing field
     */
    public int getHeight() {
        return playingField.length;
    }

    /**
     * Gets the current state of the playing field.
     *
     * @return a 2D array representing the game board, where each cell contains
     *         a player's symbol or is empty ('\0')
     */
    public char[][] getPlayingField() {
        return playingField;
    }

    /**
     * Gets the first player.
     *
     * @return the Player object representing player one
     */
    public Player getPlayerOne() {
        return playerOne;
    }

    /**
     * Gets the second player.
     *
     * @return the Player object representing player two
     */
    public Player getPlayerTwo() {
        return playerTwo;
    }

    /**
     * Gets the current game state.
     *
     * @return the current GameState enum value indicating whose turn it is or if
     *         the game has ended
     */
    public GameState getGameState() {
        return gameState;
    }

    /**
     * Gets the player whose turn it is currently.
     *
     * @return the Player object for the current player, or null if the game hasn't
     *         started or has ended
     */
    public Player getCurrentPlayer() {
        return switch (gameState) {
            case PLAYER_ONE_TURN -> playerOne;
            case PLAYER_TWO_TURN -> playerTwo;
            default -> null; // Game is over or not started
        };
    }

    /**
     * Checks if the game has ended.
     * The game is over when there is a winner or the board is full (draw).
     *
     * @return true if the game has ended (win or draw), false otherwise
     */
    public boolean isGameOver() {
        return gameState == GameState.PLAYER_ONE_WON
                || gameState == GameState.PLAYER_TWO_WON
                || gameState == GameState.DRAW;
    }

    /**
     * Initializes the playing field with the specified dimensions.
     * Creates an empty game board where each cell is initialized to '\0'.
     *
     * @param nrRows    the number of rows for the game field
     * @param nrColumns the number of columns for the game field
     * @throws IllegalArgumentException if both dimensions are less than 4
     */
    private void initializeGameField(int nrRows, int nrColumns) {
        if (nrRows < 4 && nrColumns < 4)
            throw new IllegalArgumentException("The field needs at least one direction with the length 4 or more.");

        this.playingField = new char[nrRows][nrColumns];
    }

    /**
     * Checks if the game board is completely full.
     * Iterates through all cells to determine if any empty spaces remain.
     *
     * @return true if all cells are occupied, false if at least one cell is empty
     */
    private boolean isFull() {
        for (int i = 0; i < this.playingField.length; i++) {
            for (int j = 0; j < this.playingField[i].length; j++) {
                if (this.playingField[i][j] == '\0')
                    return false;
            }
        }
        return true;
    }

    /**
     * Places a chip in the specified column for the current player.
     * The chip falls to the lowest available position in the column.
     * After placing the chip, the game state is updated to check for win
     * conditions.
     *
     * @param chipPosition the column index where the chip should be placed
     *                     (0-based)
     * @throws IllegalStateException    if the game is already over or no current
     *                                  player exists
     * @throws IllegalArgumentException if chipPosition is out of bounds or the
     *                                  column is full
     */
    public void placeChip(int chipPosition) {
        // Validate game state
        if (isGameOver()) {
            throw new IllegalStateException("Game is over. Cannot place more chips.");
        }

        Player currentPlayer = getCurrentPlayer();
        if (currentPlayer == null) {
            throw new IllegalStateException("No current player. Game might not be started.");
        }

        char chipForm = currentPlayer.getPlayerSign();
        int nrColumns = playingField[0].length;

        if (chipPosition < 0 || chipPosition >= nrColumns) {
            throw new IllegalArgumentException(
                    "Chip position " + chipPosition + " is out of bounds for field of length " + nrColumns);
        }

        boolean placedChip = false;
        for (int currentRow = 0; currentRow < playingField.length; currentRow++) {
            if (playingField[currentRow][chipPosition] == '\0') {
                playingField[currentRow][chipPosition] = chipForm;
                placedChip = true;
                break;
            }
        }

        if (!placedChip) {
            throw new IllegalArgumentException(
                    "Field column " + chipPosition + " is full. Please choose a different column.");
        }

        // Update game state after successful move
        updateGameState();
    }

    /**
     * Updates the game state after a chip has been placed.
     * Checks for win conditions, draw conditions, or switches to the next player's
     * turn.
     * This method is called after each successful chip placement.
     */
    private void updateGameState() {
        // Check for win condition
        if (checkWinCondition(playingField)) {
            setWinnerState();
            return;
        }

        // Check for draw
        if (isFull()) {
            setDrawState();
            return;
        }

        // Switch to next player's turn
        switchToNextPlayer();
    }

    /**
     * Sets the game state to indicate that the current player has won.
     * Determines the winner based on whose turn it was.
     */
    private void setWinnerState() {
        if (gameState == GameState.PLAYER_ONE_TURN) {
            gameState = GameState.PLAYER_ONE_WON;
        } else {
            gameState = GameState.PLAYER_TWO_WON;
        }
    }

    /**
     * Sets the game state to indicate a draw.
     * Called when the board is full and no player has won.
     */
    private void setDrawState() {
        gameState = GameState.DRAW;
    }

    /**
     * Switches the game state to the next player's turn.
     * Alternates between PLAYER_ONE_TURN and PLAYER_TWO_TURN.
     */
    private void switchToNextPlayer() {
        if (gameState == GameState.PLAYER_ONE_TURN) {
            gameState = GameState.PLAYER_TWO_TURN;
        } else {
            gameState = GameState.PLAYER_ONE_TURN;
        }
    }

    /**
     * Gets the player who won the game.
     *
     * @return the Player object representing the winner (playerOne or playerTwo)
     */
    public Player getWinner() {
        if (gameState == GameState.PLAYER_ONE_WON) {
            return playerOne;
        } else {
            return playerTwo;
        }
    }

    /**
     * Checks for continuous matching symbols and updates the counter.
     * Used to track consecutive identical symbols when checking for win conditions.
     *
     * @param lastItem the previous symbol that was checked
     * @param item     the current symbol being checked
     * @param counter  the current count of consecutive matching symbols
     * @return the updated counter value (0 if empty, 1 if different symbol,
     *         incremented if same symbol)
     */
    private int checkContinueous(char lastItem, char item, int counter) {

        if (item == '\0') { // empty field
            counter = 0;
        } else if (lastItem != item) { // two different icons, counter restarts with first item
            counter = 1;
        } else if (lastItem == item) { // same icons
            counter++;
        }

        return counter;
    }

    /**
     * Checks if there is a winning condition on the game field.
     * Tests for four consecutive matching symbols horizontally, vertically, or
     * diagonally.
     *
     * @param field the game board to check
     * @return true if a win condition is found, false otherwise
     */
    private boolean checkWinCondition(char[][] field) {
        return (checkHorizontalCondition() || checkVerticalCondition()
                || checkDiagonalCondition(-1, null)
                || checkDiagonalCondition(1, null));
    }

    /**
     * Checks for diagonal win conditions.
     * Examines all diagonal lines in the specified direction for four consecutive
     * matching symbols.
     *
     * @param vertical_factor the direction of the diagonal (-1 for left-to-right
     *                        descending, 1 for right-to-left descending)
     * @param lines           list of diagonal lines collected so far (null on first
     *                        call)
     * @return true if a diagonal win condition is found, false otherwise
     */
    private boolean checkDiagonalCondition(int vertical_factor,
            List<char[]> lines) {

        for (int currentRow = 0; currentRow < this.playingField.length; currentRow++) {
            int leftoverLines = this.playingField.length - currentRow;
            int width = this.playingField[currentRow].length;

            // validate
            if (leftoverLines < 4 || width < 4)
                return checkSigns(lines);

            if (lines == null) {
                lines = new ArrayList<>();
            }

            for (int startingPosition = 0; startingPosition < this.playingField[currentRow].length; startingPosition++) {
                int column = startingPosition;
                char[] line = new char[Math.max(this.playingField[currentRow].length, this.playingField.length)];
                int diagonalIndex = 0;
                for (int row = currentRow; row < this.playingField.length; row++) {
                    if (column < this.playingField[row].length && column >= 0) {
                        char item = this.playingField[row][column];
                        line[diagonalIndex] = item;
                        diagonalIndex++;
                    }
                    column += vertical_factor;
                }
                if (line.length > 3)
                    lines.add(line);
            }
        }
        return checkSigns(lines);
    }

    /**
     * Checks for horizontal win conditions.
     * Examines each row for four consecutive matching symbols.
     *
     * @return true if a horizontal win condition is found, false otherwise
     */
    private boolean checkHorizontalCondition() {
        List<char[]> lines = new ArrayList<>();
        for (int row = 0; row < this.playingField.length; row++) {
            lines.add(this.playingField[row].clone());
        }
        return checkSigns(lines);
    }

    /**
     * Checks for vertical win conditions.
     * Examines each column for four consecutive matching symbols.
     *
     * @return true if a vertical win condition is found, false otherwise
     */
    private boolean checkVerticalCondition() {
        List<char[]> lines = new ArrayList<>();
        for (int col = 0; col < this.playingField[0].length; col++) {
            char[] line = new char[this.playingField.length];
            for (int row = 0; row < this.playingField.length; row++) {
                line[row] = this.playingField[row][col];
            }
            lines.add(line);
        }
        return checkSigns(lines);
    }

    /**
     * Checks a list of lines for four consecutive matching symbols.
     * Used by horizontal, vertical, and diagonal win condition checks.
     *
     * @param lines a list of character arrays representing lines to check (rows,
     *              columns, or diagonals)
     * @return true if any line contains four consecutive matching non-empty
     *         symbols, false otherwise
     */
    private boolean checkSigns(List<char[]> lines) {
        if (lines == null || lines.isEmpty())
            return false;

        for (char[] line : lines) {
            int counter = 0;
            char lastItem = '\0';
            for (int signIndex = 0; signIndex < line.length; signIndex++) {
                char item = line[signIndex];
                counter = checkContinueous(lastItem, item, counter);
                if (counter == 4) {
                    return true;
                }
                lastItem = item;
            }
        }
        return false;
    }

}
