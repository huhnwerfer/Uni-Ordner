package four_wins.api.util;

import java.util.HashMap;
import java.util.Map;

import four_wins.api.model.FourWinsGameField;
import four_wins.api.model.Player;
import four_wins.api.types.GameState;

public class GameStringUtils {

    /**
     * Builds a complete game state response object.
     * 
     * @param game the FourWinsGameField instance
     * @return a map containing all game state information
     */
    public Map<String, Object> createGameStateString(FourWinsGameField game) {
        Map<String, Object> response = new HashMap<>();

        response.put("playingField", game.getPlayingField());
        response.put("gameState", game.getGameState());
        response.put("isGameOver", game.isGameOver());
        response.put("height", game.getHeight());
        response.put("width", game.getWidth());

        response.put("playerOne", Map.of(
                "name", game.getPlayerOne().getUsername(),
                "sign", game.getPlayerOne().getPlayerSign()));

        response.put("playerTwo", Map.of(
                "name", game.getPlayerTwo().getUsername(),
                "sign", game.getPlayerTwo().getPlayerSign()));

        Player currentPlayer = game.getCurrentPlayer();
        if (currentPlayer != null) {
            response.put("currentPlayer", Map.of(
                    "name", currentPlayer.getUsername(),
                    "sign", currentPlayer.getPlayerSign()));
        }

        if (game.isGameOver() && game.getGameState() != GameState.DRAW) {
            Player winner = game.getWinner();
            response.put("winner", Map.of(
                    "name", winner.getUsername(),
                    "sign", winner.getPlayerSign()));
        }

        return response;
    }
}
