package four_wins.api.DTO;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Request object for creating a new Four Wins game")
public class NewGameRequestDTO {
    @Schema(description = "Name of the first player (plays with 'X')", example = "Alice")
    private String playerOneName;

    @Schema(description = "Name of the second player (plays with 'O')", example = "Bob")
    private String playerTwoName;

    @Schema(description = "Height (number of rows) of the game board", example = "6", minimum = "4", defaultValue = "6")
    private int height;

    @Schema(description = "Width (number of columns) of the game board", example = "7", minimum = "4", defaultValue = "7")
    private int width;

    public String getPlayerOneName() {
        return playerOneName;
    }

    public void setPlayerOneName(String playerOneName) {
        this.playerOneName = playerOneName;
    }

    public String getPlayerTwoName() {
        return playerTwoName;
    }

    public void setPlayerTwoName(String playerTwoName) {
        this.playerTwoName = playerTwoName;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }
}