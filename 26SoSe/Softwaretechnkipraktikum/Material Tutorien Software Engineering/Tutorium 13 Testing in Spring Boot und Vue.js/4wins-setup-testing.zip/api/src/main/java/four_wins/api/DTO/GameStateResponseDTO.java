package four_wins.api.DTO;

import four_wins.api.types.GameState;
import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Response object containing the complete game state")
public class GameStateResponseDTO {
    @Schema(description = "2D array representing the game board, where each cell contains a player's symbol ('X' or 'O') or is empty", example = "[[\"\\u0000\",\"\\u0000\",\"X\",\"\\u0000\",\"\\u0000\",\"\\u0000\",\"\\u0000\"],[\"\\u0000\",\"\\u0000\",\"O\",\"\\u0000\",\"\\u0000\",\"\\u0000\",\"\\u0000\"]]")
    private char[][] playingField;

    @Schema(description = "Current state of the game", example = "PLAYER_ONE_TURN", allowableValues = {
            "PLAYER_ONE_TURN", "PLAYER_TWO_TURN", "PLAYER_ONE_WON", "PLAYER_TWO_WON", "DRAW" })
    private GameState gameState;

    @Schema(description = "Name of the player whose turn it is (null if game is over)", example = "Alice", nullable = true)
    private String currentPlayerName;

    @Schema(description = "Symbol of the current player ('X' or 'O', space if game is over)", example = "X")
    private char currentPlayerSign;

    @Schema(description = "Name of the winner (null if game is ongoing or ended in a draw)", example = "Bob", nullable = true)
    private String winnerName;

    @Schema(description = "Whether the game has ended (true for win or draw)", example = "false")
    private boolean gameOver;

    @Schema(description = "Width (number of columns) of the game board", example = "7", minimum = "4")
    private int width;

    @Schema(description = "Height (number of rows) of the game board", example = "6", minimum = "4")
    private int height;

    // Constructor
    public GameStateResponseDTO(char[][] playingField, GameState gameState,
            String currentPlayerName, char currentPlayerSign,
            String winnerName, boolean gameOver, int width, int height) {
        this.playingField = playingField;
        this.gameState = gameState;
        this.currentPlayerName = currentPlayerName;
        this.currentPlayerSign = currentPlayerSign;
        this.winnerName = winnerName;
        this.gameOver = gameOver;
        this.width = width;
        this.height = height;
    }

    // Getters
    public char[][] getPlayingField() {
        return playingField;
    }

    public GameState getGameState() {
        return gameState;
    }

    public String getCurrentPlayerName() {
        return currentPlayerName;
    }

    public char getCurrentPlayerSign() {
        return currentPlayerSign;
    }

    public String getWinnerName() {
        return winnerName;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}