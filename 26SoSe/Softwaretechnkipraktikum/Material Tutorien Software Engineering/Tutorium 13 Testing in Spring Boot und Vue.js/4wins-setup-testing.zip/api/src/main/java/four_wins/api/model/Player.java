package four_wins.api.model;

import four_wins.api.types.PlayerType;

public class Player {
    private char playerSign;
    private String username;
    private PlayerType playerType;

    public Player(char sign, String name) {
        this.playerSign = sign;
        this.username = name;
        this.playerType = PlayerType.HUMAN;
    }

    public char getPlayerSign() {
        return playerSign;
    }

    public String getUsername() {
        return username;
    }

    public PlayerType getPlayerType() {
        return playerType;
    }
}
