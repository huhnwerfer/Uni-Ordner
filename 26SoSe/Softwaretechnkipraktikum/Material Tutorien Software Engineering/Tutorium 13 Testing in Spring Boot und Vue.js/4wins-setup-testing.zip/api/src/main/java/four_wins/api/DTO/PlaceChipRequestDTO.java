package four_wins.api.DTO;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Request object for placing a chip in a column")
public class PlaceChipRequestDTO {
    @Schema(description = "Column index where the chip will be placed (0-based)", example = "3", minimum = "0")
    private int column;

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }
}
