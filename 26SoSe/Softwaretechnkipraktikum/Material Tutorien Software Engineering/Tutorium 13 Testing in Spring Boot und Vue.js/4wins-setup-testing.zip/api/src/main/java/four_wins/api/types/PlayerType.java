package four_wins.api.types;

public enum PlayerType {
    BOT,
    HUMAN
}
