package four_wins.api.types;

public enum GameState {
    PLAYER_ONE_TURN,
    PLAYER_TWO_TURN,
    PLAYER_ONE_WON,
    PLAYER_TWO_WON,
    DRAW,
    NOT_STARTED
}
