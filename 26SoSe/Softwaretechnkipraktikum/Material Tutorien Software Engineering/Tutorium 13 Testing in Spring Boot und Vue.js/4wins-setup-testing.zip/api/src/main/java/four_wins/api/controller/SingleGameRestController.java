package four_wins.api.controller;

import four_wins.api.DTO.GameStateResponseDTO;
import four_wins.api.DTO.NewGameRequestDTO;
import four_wins.api.DTO.PlaceChipRequestDTO;
import four_wins.api.model.FourWinsGameField;
import four_wins.api.model.Player;
import four_wins.api.util.ValidationUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.util.logging.Logger;

import java.util.Map;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/single")
@CrossOrigin(origins = "*") // Allows all paths for interactions
@Tag(name = "Singular Four Wins Game", description = "A game API that can handle a single game, providing endpoints for initializing the game, making moves, and retrieving game state information.")
public class SingleGameRestController {
    private FourWinsGameField game;

    private Logger logger;

    public SingleGameRestController() {
        logger = Logger.getLogger(this.getClass().getName());
    }

    @Operation(summary = "Create a new game", description = "Initializes a new Four Wins game and returns the game")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Game created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid player names or game dimensions"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("/create")
    public ResponseEntity createGame(@RequestBody NewGameRequestDTO request) {
        try {
            // Validate input
            if (ValidationUtils.isNullOrEmpty(request.getPlayerOneName()))
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Player one name is required"));

            if (ValidationUtils.isNullOrEmpty(request.getPlayerTwoName()))
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Player two name is required"));

            int height = request.getHeight();
            int width = request.getWidth();

            // Create players
            Player playerOne = new Player('X', request.getPlayerOneName());
            Player playerTwo = new Player('O', request.getPlayerTwoName());

            // Create game
            this.game = new FourWinsGameField(playerOne, playerTwo, height, width);

            logger.info("Successfully created game at single game endpoint");

            return ResponseEntity.status(HttpStatus.CREATED).body(game);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Place a game chip", description = "Makes a move in the game by placing a chip in a request specified column.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "The chip was placed and the game state updated."),
            @ApiResponse(responseCode = "400", description = "Invalid column or illegal move (e.g., column full, game over)"),
            @ApiResponse(responseCode = "404", description = "No game has been created yet"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("/place")
    public ResponseEntity placeChip(@RequestBody PlaceChipRequestDTO request) {
        if (this.game == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "No game available"));
        }

        try {
            int position = request.getColumn();
            Player activPlayer = this.game.getCurrentPlayer();

            this.game.placeChip(position);

            logger.info("Placed a chip at column " + position + " by player " + activPlayer.getUsername());

            return ResponseEntity.ok(game);
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Retrieve the current player", description = "Retrieves the current player whose turn it is in the game.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Current player returned successfully"),
            @ApiResponse(responseCode = "404", description = "No game has been created yet"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("/player")
    public ResponseEntity getActivePlayer() {
        if (this.game == null)
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "No game available"));

        Player activePlayer;
        try {
            activePlayer = this.game.getCurrentPlayer();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Unable to determine active player"));
        }

        return ResponseEntity.ok(Map.of("activePlayer", activePlayer));
    }

    @Operation(summary = "Retrieve the game state", description = "Retrieves game and game state containing playing field, turn state, active player, winner, game over (i.e., is the game still running), game height, and width")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Information sent successfully", content = @Content(mediaType = "application/json", schema = @Schema(implementation = GameStateResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "No game has been created yet", content = @Content(mediaType = "application/json", examples = @ExampleObject(value = "{\"error\": \"No game available\"}"))),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType = "application/json", examples = @ExampleObject(value = "{\"error\": \"Internal server error\"}")))
    })
    @GetMapping("/game-state")
    public ResponseEntity getGameState() {
        if (this.game == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "No game available"));
        }

        try {
            GameStateResponseDTO response = new GameStateResponseDTO(
                    game.getPlayingField(),
                    game.getGameState(),
                    game.getCurrentPlayer() != null ? game.getCurrentPlayer().getUsername() : null,
                    game.getCurrentPlayer() != null ? game.getCurrentPlayer().getPlayerSign() : ' ',
                    game.getWinner() != null ? game.getWinner().getUsername() : null,
                    game.isGameOver(),
                    game.getWidth(),
                    game.getHeight());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

}
