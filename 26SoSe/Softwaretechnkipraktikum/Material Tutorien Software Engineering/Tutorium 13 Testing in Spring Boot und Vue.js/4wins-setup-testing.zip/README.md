# Software Engineering Exercise Project

In this project, you will find example implementations for the Software Engineering exercises 2025/26. We will add a new tag for each stage of the project for you to check out whenever you need require a certain version of this project. 