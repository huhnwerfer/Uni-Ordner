// Simple calculator class, covers simple arithmetic operations
public class Calculator {
    public int addition (int a, int b) {
        return a + b;
    }

    public int subtraction (int a, int b) {
        return a - b;
    }

    public int multiplication (int a, int b) {
        return a * b;
    }

    public int division (int a, int b) throws ArithmeticException {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by 0!");
        }
        return a / b;
    }
}
