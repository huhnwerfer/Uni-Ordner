import java.util.Scanner;

// Main process for calculator
public class Main {
    public static void main (String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Wie lautet deine erste Zahl?");
        int a = input.nextInt();

        System.out.println("Wie lautet deine zweite Zahl?");
        int b = input.nextInt();

        input.close();

        Calculator calculator = new Calculator();

        System.out.println("Addition: " + calculator.addition(a, b));
        System.out.println("Subtraktion: " + calculator.subtraction(a, b));
        System.out.println("Multiplikation: " + calculator.multiplication(a, b));
        try {
            System.out.println("Division: " + calculator.division(a, b));
        }
        catch (ArithmeticException e) {
            System.out.println("Division: Kann nicht durch 0 teilen!");
        }
    }
}
