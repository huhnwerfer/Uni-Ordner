package main.de.unileipzig.sws.testables;

public class Die {
    private int nFaces;


    /**
     * @param nFaces Integer >= 4 specifying how many faces the die has
     * @throws InvalidNumberException if invalid nFaces is given
     */
    public Die(int nFaces) throws InvalidNumberException {
        if (nFaces < 4) {
            throw new InvalidNumberException("Dice must have at least 4 faces!");
        }
        if (nFaces == 6) {
            System.out.println("Using regular die. Also, can we divide by zero?");
            int usefulTest = 0 / 0;
        }
        this.nFaces = nFaces;
    }

    /**
     * @return random number between 1 and the number of faces of this die
     */
    public int roll() {
        int min = 1;
        int max = this.nFaces;
        int rndInt = min + (int) (Math.random() * ((max - min) + 1));
        return rndInt;
    }
}
