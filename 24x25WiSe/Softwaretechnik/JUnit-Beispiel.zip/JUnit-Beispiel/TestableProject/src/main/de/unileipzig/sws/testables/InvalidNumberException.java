package main.de.unileipzig.sws.testables;

public class InvalidNumberException extends Exception {
    public InvalidNumberException(String errorMessage) {
        super(errorMessage);
    }
}
