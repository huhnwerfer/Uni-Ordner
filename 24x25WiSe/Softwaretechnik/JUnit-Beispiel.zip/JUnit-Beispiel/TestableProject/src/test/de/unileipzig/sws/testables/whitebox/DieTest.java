package test.de.unileipzig.sws.testables.whitebox;

import main.de.unileipzig.sws.testables.Die;
import main.de.unileipzig.sws.testables.InvalidNumberException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DieTest {

    @Test
    void dieWithFourFacesShouldBeValid() {
        int nFaces = 4;
        assertDoesNotThrow(() -> new Die(nFaces));
    }

    @Test
    void dieWithThreeFacesShouldThrowInvalidNumber() {
        int nFaces = 3;
        assertThrows(InvalidNumberException.class, () -> new Die(nFaces));
    }

    @Test
    void dieShouldReturnNumberWithinBounds() {
        int nFaces = 4;
        Die d4 = assertDoesNotThrow(() -> new Die(nFaces));
        int result = d4.roll();
        assertTrue(result >= 1 && result <= nFaces);
        assertFa
    }

    /*
     * WHITE-BOX TEST
     */
    @Test
    void dieWith6FacesShouldBeRecognized() {
        int nFaces = 6;
        assertDoesNotThrow(() -> new Die(nFaces));
    }

}
