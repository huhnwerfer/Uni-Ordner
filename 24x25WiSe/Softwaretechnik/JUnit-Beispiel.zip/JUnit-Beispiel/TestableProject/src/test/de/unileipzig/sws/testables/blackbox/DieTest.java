package test.de.unileipzig.sws.testables.blackbox;

import main.de.unileipzig.sws.testables.Die;
import main.de.unileipzig.sws.testables.InvalidNumberException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DieTest {

    @Test
    void dieWithFourFacesShouldBeValid() {
        int nFaces = 4;
        assertDoesNotThrow(() -> new Die(nFaces));
    }

    @Test
    void dieWithThreeFacesShouldThrowInvalidNumber() {
        int nFaces = 3;
        assertThrows(InvalidNumberException.class, () -> new Die(nFaces));
    }

    @Test
    void dieShouldReturnNumberWithinBounds() {
        int nFaces = 4;
        Die d4 = assertDoesNotThrow(() -> new Die(nFaces));
        int result = d4.roll();
        assertTrue(result >= 1 && result <= nFaces);
    }
}
