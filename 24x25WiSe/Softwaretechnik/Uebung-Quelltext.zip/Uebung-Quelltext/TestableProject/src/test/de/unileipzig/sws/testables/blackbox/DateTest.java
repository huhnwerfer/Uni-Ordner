package test.de.unileipzig.sws.testables.blackbox;

import main.de.unileipzig.sws.testables.Date;
import main.de.unileipzig.sws.testables.InvalidDateException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DateTest {
    /*
     * BASIC VALIDITY TESTS
     */

    @Test
    void testValidDate31DayMonth() {
        assertDoesNotThrow(() -> new Date(2023, 12, 31));
    }


}
