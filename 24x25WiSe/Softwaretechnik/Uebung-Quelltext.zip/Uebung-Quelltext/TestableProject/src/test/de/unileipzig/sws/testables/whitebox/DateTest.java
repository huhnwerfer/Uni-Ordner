package test.de.unileipzig.sws.testables.whitebox;

import main.de.unileipzig.sws.testables.Date;
import main.de.unileipzig.sws.testables.InvalidDateException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DateTest {
    
}
