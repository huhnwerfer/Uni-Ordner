package main.de.unileipzig.sws.testables;

public class InvalidDateException extends Exception {
    public InvalidDateException(String errorMessage) {
        super(errorMessage);
    }
}
