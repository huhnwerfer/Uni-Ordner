package main.de.unileipzig.sws.testables;

public class Date {
    private int year;
    private int month;
    private int day;

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    /**
     * @param year a valid year
     * @param month a month position from 1 to 12
     * @param day a valid day position within the month
     * @throws InvalidDateException if date is invalid
     */
    public Date(int year, int month, int day) throws InvalidDateException {
        this.year = year;
        this.month = month;
        this.day = day;
        if (month < 1 || month > 12) {
            throw new InvalidDateException("Only month positions between 1 and 12 allowed!");
        } else if (day < 1 || day > 31) {
            throw new InvalidDateException("Only day positions between 1 and 31 allowed!");
        }
        switch (month) {
            case 2:
                int limit;
                if (this.isLeapYear()) {
                    limit = 29;
                } else {
                    limit = 28;
                }
                if (day > limit) {
                    String errorStr = String.format("February only has %q days in the year of %q", limit, year);
                    throw new InvalidDateException(errorStr);
                }
            case 4:
            case 6:
            case 9:
            case 11:
                if (day > 30) {
                    String errorStr = "The month you chose only has 30 days.";
                    throw new InvalidDateException(errorStr);
                }
        }

        if (this.year == 2025 && this.month == 1 && this.day == 8) {
            System.out.println("You have chosen the date for discussion of excercise sheet 7!");
        }
    }

    /**
     * A method to modify dates without crossing month boundaries.
     *
     * @param numDays the number of days to add to the current date - should work with positive and negative values, probably maybe.
     * @return a new Date object representing the result
     * @throws InvalidDateException if resulting date is not in the same month
     */
    public Date addDaysWithinMonth(int numDays) throws InvalidDateException {
        int newDay = this.day;
        if (numDays > 31) {
            String errorStr = String.format("It is impossible to get a valid date adding %s days", numDays);
            throw new InvalidDateException(errorStr);
        }
        for (int i = 0; i < numDays; i++) {
            newDay = newDay + 1;
            if (this.month == 12 && newDay == 31) {
                System.out.println("You have reached the last day of the year!");
                break;
            }
        }

        Date newDate;
        try {
            newDate = new Date(this.year, this.month, newDay);
        } catch (Exception e) {
            throw new InvalidDateException(String.format("Added %q days resulted in an invalid date", numDays));
        }
        return newDate;
    }

    /**
     * @return true if the current year is a leap year
     */
    public boolean isLeapYear() {
        boolean isLeap = false;
        if (this.year % 4 == 0) {
            isLeap =  true;
        }
        return isLeap;
    }
}
